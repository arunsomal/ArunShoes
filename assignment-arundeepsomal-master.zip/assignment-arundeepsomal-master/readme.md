# CTEC3905 Assignment

This assignment contains the website to a Shoe review website that I made using HTML, CSS and JavaScript. I created four HTML pages to demonstrate my web developing ability that all come together to make a cohesive website.


## homepage.html
The homepage.html file is the first and main page that the user will see when viewing the website. It gives a basic introduction to the website with some links on the review section of the website. It also features a slideshow that can scroll through 3 main pictures that was made via HTML, CSS, and JavaScript. The slideshow was made to give the website a professional and diverse feel, and I found the idea from w3 schools (https://www.w3schools.com/howto/howto_js_slideshow.asp) and decided to try and implement it into my project. I made some changes towards it, by changing the VAR used as well as adding different image links in the slideshow.


## index.html
The index page for my project is the review section of the website that contains all the reviews for shoes. The page includes some classes such as 'rev-section' which stands for review section. The rest of the classes are made to give the page the gird structure, where I can display all the reviews in boxes within the page. I found the idea on YouTube from a video (https://www.youtube.com/watch?v=WXmn9lk1tgk) and used some of the classes for my shoe review section. I edited and changed the code so it would fit with multiple shoe reviews and changed the CSS, so the style had more of a sneaker page aesthetic.

##comingup.html
The coming up page was page that involved any future shoes that were releasing this year, so I created an informative page that used article tags with nicely sized images and written information about the rumoured shoes coming out this year.

##aboutus.html
I felt the website needed an about page to make it feel professional, so I added in some key information about the website as well as about my experience in shoes. I even linked a review for one of my favourite shoes that takes you to the index page. The page uses heading tags as well as classes to organise the page formally.

##styles.css

The CSS style page provides all the styling for every HTML page involved in the project, the CSS is linked with every page and is responsible for the layout, design, and responsiveness of the website. It also allows for the website to be mobile friendly when the page gets shrunk to a smaller screen. It helps every section including the navigation, the footer and the body of the page.

##scripts.js
The scripts.js page allows my website to be responsive and act out certain function. the first JavaScript I have executed involved a 'menuToggler', and this allows for the navigation links to open once the navigation button is pressed when the screen is below 1000px.
I also have some JavaScript for the slideshow in the homepage.html. The JavaScript code was found in the w3 schools slide show tutorial, but I did make some changes such as taking out the VAR function and replacing it. Unfortunately, the JavaScript for the slideshow had some errors in the console log that I tried to fix, but it seems as there still may be some issue there that I couldn't solve.

 ##mobileToggler
 When making the screen go to mobile size on inspect mode and changing pages, the screen may mess up the layout originally, but when clicking out of mobile view and entering in again the layout will look correct again. I'm not sure why this is and I have tried to fix it, but if the layout goes wrong on mobile view, please re-enter mobile view and the problem will be fixed.   
